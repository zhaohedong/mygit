from setuptools import setup
setup(
        name="test_tox",
        script=['test_hello'],
)

